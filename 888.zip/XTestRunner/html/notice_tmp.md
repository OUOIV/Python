__【{{title}}】测试结果__
  * 标题： {{title}}
  * 测试人员： {{tester}}
  * 开始时间： {{start_time}}
  * 结束时间： {{end_time}}
  * 运行时长： {{duration}}
  * 成功用例： {{p_number}}  成功率：{{pass_rate}}
  * 失败用例： {{f_number}}  失败率：{{failure_rate}}
  * 错误用例： {{e_number}}  错误率：{{error_rate}}
  * 跳过用例： {{s_number}}  跳过率：{{skip_rate}}
